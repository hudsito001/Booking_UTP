<?php
/* $Id: text_plain__formatted.inc.php 5208 2003-11-26 22:52:25Z rabus $ */
// vim: expandtab sw=4 ts=4 sts=4:

function PMA_transformation_text_plain__formatted($buffer, $options = array(), $meta = '') {
    return $buffer;
}

?>
