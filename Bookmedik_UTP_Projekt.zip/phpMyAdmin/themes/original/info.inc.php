<?php
/* $Id: info.inc.php,v 2.6.2.1 2006/08/14 12:41:29 cybot_tm Exp $ */
/* Theme information */
$theme_name = 'Original';
$theme_full_version = '2.9';
?>
