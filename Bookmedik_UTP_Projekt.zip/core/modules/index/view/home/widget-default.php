<div class="row">
<div class="col-md-12">
<h1>Sistema de Citas Medicas UTP</h1>
<p>Bienvenido a <b>ReservasUTP</b> un Sistema de Citas Medicas util para consultorios medicos y/o medicos independientes.</p>
<p>Caracteristicas:</p>
<ul>
	<li>Gestion de Citas</li>
	<li>Gestion de Medicos</li>
	<li>Gestion de Pacientes</li>
	<li>Gestion de Usuarios con Acceso al Sistema</li>
	<li>Historial de Citas por Paciente</li>
	<li>Historial de Citas por Medico</li>
	<li>Buscador avanzado por : Palabra clave, medico, paciente y fecha.</li>
</ul>
<p>Grupo UTP </p>
</div>
</div>

