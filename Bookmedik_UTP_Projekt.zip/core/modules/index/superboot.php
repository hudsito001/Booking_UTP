<?php
// superboot.php

// El codigo siguiente se ejecuta en todas los views y action

// echo "Hello superboot";




?>